"""Module: vector_analysis_tools.py

This module contains the VectorAnalysisTools class.
"""

from typing import TYPE_CHECKING, NamedTuple

from qgis.core import (
    Qgis,
    QgsFeature,
    QgsFeatureRequest,
    QgsFields,
    QgsGeometry,
    QgsPointXY,
    QgsSpatialIndex,
    QgsVectorDataProvider,
    QgsVectorLayer,
    QgsWkbTypes,
)

from .constants import Names, NewPointLayerFields, Numbers
from .logs_and_errors import log_debug, lvl

if TYPE_CHECKING:
    from qgis.core import QgsRectangle


class FieldNames(NamedTuple):
    """Holds the names of special fields found in the layer.

    Attributes:
        dim: The name of the dimension field, or None if not found.
        load: The name of the load field, or None if not found.
    """

    dim: str | None
    load: str | None


class VectorAnalysisTools:
    """A base class for finding features in a vector layer."""

    def __init__(
        self,
        selected_layer: QgsVectorLayer,
        temp_point_layer: QgsVectorLayer,
    ) -> None:
        """Initialize the toolset with the selected and target layers.

        Args:
            selected_layer: The QgsVectorLayer to search within.
            temp_point_layer: The temporary QgsVectorLayer to add new features to.
        """
        self.selected_layer: QgsVectorLayer = selected_layer
        self.new_layer: QgsVectorLayer = temp_point_layer
        log_debug(f"Creating spatial index for layer '{selected_layer.name()}'.")
        request: QgsFeatureRequest = QgsFeatureRequest().setNoAttributes()
        self.selected_layer_index: QgsSpatialIndex = QgsSpatialIndex(
            selected_layer.getFeatures(request)
        )
        log_debug("Spatial index created.", lvl.Success)

        fields: FieldNames = self.find_layer_fields(selected_layer)
        self.dim_field_name: str | None = fields.dim
        self.load_field_name: str | None = fields.load

    @staticmethod
    def find_layer_fields(layer: QgsVectorLayer) -> FieldNames:
        """Find matching dimension and load field names from the constants.

        Args:
            layer: The layer to search for the fields.

        Returns:
            A NamedTuple containing the found field names.
        """
        layer_fields: QgsFields = layer.fields()

        def _find(candidates: tuple[str, ...]) -> str | None:
            return next(
                (name for name in candidates if layer_fields.lookupField(name) != -1),
                None,
            )

        dim_name: str | None = _find(Names.sel_layer_field_dim)
        load_name: str | None = _find(Names.sel_layer_field_load)

        if dim_name:
            log_debug(f"Found dimension field: '{dim_name}'", lvl.Success)
        else:
            log_debug("No dimension field found in the selected layer.", lvl.Warning)

        if load_name:
            log_debug(f"Found load field: '{load_name}'", lvl.Success)

        return FieldNames(dim_name, load_name)

    def create_feature(self, geometry: QgsGeometry, attributes: dict) -> bool:
        """Create a new feature in the new layer.

        Args:
            geometry: The geometry for the new feature.
            attributes: A dictionary of attribute values.

        Returns:
            True if the feature was added successfully, False otherwise.
        """
        data_provider: QgsVectorDataProvider | None = self.new_layer.dataProvider()
        if data_provider is None:
            log_debug("Data provider is None for new_layer.", lvl.Critical)
            return False

        layer_fields: QgsFields = self.new_layer.fields()
        field_names: list[str] = [
            layer_fields[idx].name() for idx in range(layer_fields.count())
        ]

        attr_values: list = [
            attributes.get(field_name)
            for field_name in field_names
            if field_name.lower() != "fid"
        ]
        new_feature = QgsFeature(layer_fields)
        new_feature.setGeometry(geometry)
        new_feature.setAttributes(attr_values)

        return self.new_layer.addFeature(new_feature)

    def get_connected_attributes(self, connected_features: list[QgsFeature]) -> dict:
        """Extract attributes from connected features.

        Constructs a dictionary containing a string representation of connected
        original IDs and, if available, the dimensions found in the connected
        features.

        Args:
            connected_features: A list of features connected to the point.

        Returns:
            A dictionary of attributes derived from the connected features.
        """

        # Get connected feature IDs (line objects)
        connected_ids: list[int] = sorted(
            {feature.attribute("original_fid") for feature in connected_features}
        )
        attributes: dict = {
            NewPointLayerFields.connected_fid.field_name: Names.separator.join(
                str(id_int) or "???" for id_int in connected_ids
            )
        }
        # Get dimension values if the dimension field was found
        if self.dim_field_name and (
            dims := sorted(
                {
                    int(feat[self.dim_field_name])
                    for feat in connected_features
                    if feat.attribute(self.dim_field_name) is not None
                },
                reverse=True,
            )
        ):
            attributes[NewPointLayerFields.dim_1.field_name] = dims[0]
            if len(dims) > 1:
                attributes[NewPointLayerFields.dim_2.field_name] = dims[-1]

        return attributes

    def get_intersecting_features(self, search_geom: QgsGeometry) -> list[QgsFeature]:
        """Find intersecting features for a given geometry.

        Uses the spatial index of the selected layer to quickly find candidates.

        Args:
            search_geom: The geometry to search for intersections with.

        Returns:
            A list of features that intersect with the search geometry.
        """
        search_rect: QgsRectangle = search_geom.boundingBox()
        candidate_ids: list[int] = self.selected_layer_index.intersects(search_rect)
        return [
            self.selected_layer.getFeature(feat_id)
            for feat_id in candidate_ids
            if self.selected_layer.getFeature(feat_id)
            .geometry()
            .intersects(search_geom)
        ]

    @staticmethod
    def get_start_end_of_line(feature: QgsFeature) -> list[QgsPointXY]:
        """Get the start and end points of a line feature's geometry.

        For MultiLineStrings, this returns the start and end points of every
        part.

        Args:
            feature: The line feature.

        Returns:
            A list containing the start and end points (QgsPointXY) of all parts.
        """
        points: list = []
        geom: QgsGeometry = feature.geometry()
        if not geom:
            return points

        wkb_type: Qgis.WkbType = geom.wkbType()
        lines: list = []
        if wkb_type == QgsWkbTypes.LineString:
            lines.append(geom.asPolyline())
        elif wkb_type == QgsWkbTypes.MultiLineString:
            lines.extend(geom.asMultiPolyline())

        for line in lines:
            if len(line) > 1:
                points.extend([line[0], line[-1]])
        return points

    @staticmethod
    def calculate_angle(p1: QgsPointXY, p2: QgsPointXY, p3: QgsPointXY) -> float:
        """Calculate the deflection angle between two connected line segments.

        This function calculates the angle of deflection at point `p2`, which
        connects segments `p1-p2` and `p2-p3`.

        * A straight line (p1-p2-p3 are collinear) will return 0°.
        * A 90-degree turn will return 90°.
        * A U-turn (p1 and p3 are at the same location) will return 180°.

        Args:
            p1: The start point of the first segment.
            p2: The common point (vertex) where the segments meet.
            p3: The end point of the second segment.

        Returns:
            The deflection angle in degrees, from 0 to 180.
        """
        # Check for coincident points which would make angle calculation invalid.
        if p2.compare(p1, Numbers.tiny_number) or p2.compare(p3, Numbers.tiny_number):
            log_debug("Coincident points found for angle calculation.", lvl.Warning)
            # Coincident points mean the lines are on top of each other (a U-turn).
            return Numbers.circle_semi

        # Azimuth of the incoming segment (p1 -> p2)
        azimuth_in: float = p1.azimuth(p2)
        # Azimuth of the outgoing segment (p2 -> p3)
        azimuth_out: float = p2.azimuth(p3)

        # The angle between the two vectors
        angle_diff: float = abs(azimuth_in - azimuth_out)

        # The deflection angle is 180 degrees minus the smaller angle between the
        # two vectors.
        if angle_diff > Numbers.circle_semi:
            angle_diff = Numbers.circle_full - angle_diff

        return angle_diff

    def get_adjacent_vertices(
        self, point: QgsPointXY, feature: QgsFeature
    ) -> tuple[QgsPointXY | None, QgsPointXY | None]:
        """Find vertices adjacent to a point on a feature's geometry.

        Finds the vertex on the feature that matches the input point and returns
        the vertices immediately before and after it. Returns None for both
        if the point is an endpoint or not a vertex.

        Args:
            point: The vertex on the feature.
            feature: The feature containing the geometry.

        Returns:
            A tuple containing the previous and next vertices as QgsPointXY.
            Returns (None, None) if the point is an endpoint or not a vertex.
        """
        geom: QgsGeometry = feature.geometry()
        if not geom:
            return None, None

        # Find the closest vertex on the geometry to the given point
        vertex: tuple[QgsPointXY, int, int, int, float] = geom.closestVertex(point)
        closest_v: QgsPointXY = vertex[0]
        vertex_idx: int = vertex[1]
        dist_sq: float = vertex[4]

        # Ensure the point is actually a vertex (not an intermediate point on a segment)
        if dist_sq > Numbers.tiny_number**2:
            return None, None

        # Check if the vertex is an endpoint of its line part
        if self.is_endpoint(closest_v, feature):
            return None, None

        # Get the vertices before and after the found vertex
        p_before = QgsPointXY(geom.vertexAt(vertex_idx - 1))
        p_after = QgsPointXY(geom.vertexAt(vertex_idx + 1))

        return p_before, p_after

    def get_adjacent_points_on_segment(
        self, point: QgsPointXY, feature: QgsFeature
    ) -> tuple[QgsPointXY | None, QgsPointXY | None]:
        """Find the start and end vertices of the segment a point lies on.

        Finds the segment of the feature's geometry that is closest to the
        input point and returns the start and end vertices of that segment.

        Args:
            point: The point on or near the feature.
            feature: The feature containing the geometry.

        Returns:
            A tuple containing the start and end vertices of the segment.
            Returns (None, None) if the point is not on a segment or on error.
        """
        geom: QgsGeometry = feature.geometry()
        if not geom:
            return None, None

        # Find the segment of the line closest to the point
        segment: tuple[float, QgsPointXY, int, int] = geom.closestSegmentWithContext(
            point
        )
        dist_sq: float = segment[0]
        after_vertex_idx: int = segment[2]

        # Ensure the point is actually on the line
        if dist_sq < 0 or dist_sq > Numbers.tiny_number**2:
            log_debug(
                f"Point {point.asWkt()} is not on the line geometry of "
                f"feature {feature.attribute('original_fid')}.",
                lvl.Warning,
            )
            return None, None

        try:
            # after_vertex_idx is the index of the vertex at the END of the segment
            # Get the vertices that define the segment
            p_before = QgsPointXY(geom.vertexAt(after_vertex_idx - 1))
            p_after = QgsPointXY(geom.vertexAt(after_vertex_idx))
        except ValueError:
            log_debug(
                f"Invalid vertex index for feature "
                f"'{feature.attribute('original_fid')}'.",
                lvl.Warning,
            )
            return None, None

        return p_before, p_after

    def is_endpoint(self, point: QgsPointXY, feature: QgsFeature) -> bool:
        """Check if a point is an endpoint of a feature's line geometry.

        Args:
            point: The point to check.
            feature: The feature to check against.

        Returns:
            True if the point is a start or end point of the feature's geometry,
            False otherwise.
        """
        if start_end_points := self.get_start_end_of_line(feature):
            return any(
                point.compare(endpoint, Numbers.tiny_number)
                for endpoint in start_end_points
            )
        return False

    def get_other_endpoint(
        self, feature: QgsFeature, reference_point: QgsPointXY
    ) -> QgsPointXY | None:
        """Get the endpoint of a line feature that is furthest from a reference point.

        This is useful for finding the "remote" end of a line when you have an
        intersection point near one of its ends.

        Args:
            feature: The line feature.
            reference_point: The point to measure distance from.

        Returns:
            The QgsPointXY of the other endpoint, or None if endpoints cannot be
            determined.
        """
        endpoints: list[QgsPointXY] = self.get_start_end_of_line(feature)
        if len(endpoints) != 2:  # noqa: PLR2004
            return None

        p1: QgsPointXY = endpoints[0]
        p2: QgsPointXY = endpoints[1]
        return p2 if p1.distance(reference_point) < p2.distance(reference_point) else p1

    def get_point_along_line(
        self, start_point: QgsPointXY, feature: QgsFeature, distance: float
    ) -> QgsPointXY | None:
        """Calculate a point at a specific distance from the start point.

        This method projects a point from `start_point` towards the other end of
        the feature's geometry. `start_point` is assumed to be one of the
        feature's endpoints.

        Args:
            start_point: The starting point on the line (must be an endpoint).
            feature: The line feature.
            distance: The distance to move along the line.

        Returns:
            The calculated point, or None if the other endpoint cannot be found.
        """
        other_endpoint: QgsPointXY | None = self.get_other_endpoint(
            feature, start_point
        )
        if not other_endpoint:
            return None

        azimuth: float = start_point.azimuth(other_endpoint)
        return start_point.project(distance, azimuth)

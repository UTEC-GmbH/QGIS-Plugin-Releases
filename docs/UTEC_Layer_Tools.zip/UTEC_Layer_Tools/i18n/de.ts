<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE" sourcelanguage="en_US">
<context>
    <name>GeoPackage</name>
    <message>
        <location filename="../modules/geopackage.py" line="871"/>
        <source>used by</source>
        <translation>Benutzt von</translation>
    </message>
    <message>
        <location filename="../modules/geopackage.py" line="875"/>
        <source>

This can lead to to unexpected results (especially if used by multiple layers). 

Do you want to continue?</source>
        <translation>\n\nDas kann unerwartete Auswirkungen haben (insbesondere, wenn mehrere Layer diese Layer als Datenquelle verwenden).\n\nMöchten Sie fortfahren?</translation>
    </message>
    <message>
        <location filename="../modules/geopackage.py" line="878"/>
        <source>Overwrite Warning</source>
        <translation>Warnung</translation>
    </message>
    <message>
        <location filename="../modules/geopackage.py" line="87"/>
        <source>Enter a layer name.</source>
        <translation>Bitte Layernamen eintragen.</translation>
    </message>
    <message>
        <location filename="../modules/geopackage.py" line="89"/>
        <source>The layer name is invalid.</source>
        <translation>Der Name ist ungültig.</translation>
    </message>
    <message>
        <location filename="../modules/geopackage.py" line="91"/>
        <source>Names starting with &apos;gpkg_&apos; or &apos;sqlite_&apos; are reserved.</source>
        <translation>Der Name darf nicth mit &apos;gpkg_&apos; oder &apos;sqlite_&apos; anfangen.</translation>
    </message>
    <message>
        <location filename="../modules/geopackage.py" line="95"/>
        <source>A layer with this name already exists in the GeoPackage.</source>
        <translation>Ein Layer mit diesem Namen ist schon im GeoPackage vorhanden.</translation>
    </message>
    <message>
        <location filename="../modules/geopackage.py" line="109"/>
        <source>Create New GeoPackage Layer</source>
        <translation>Neuen GeoPackage-Layer erstellen</translation>
    </message>
    <message>
        <location filename="../modules/geopackage.py" line="127"/>
        <source>Geometry type:</source>
        <translation>Geometrietyp:</translation>
    </message>
    <message>
        <location filename="../modules/geopackage.py" line="133"/>
        <source>Layer name:</source>
        <translation>Layername:</translation>
    </message>
    <message>
        <location filename="../modules/geopackage.py" line="190"/>
        <source>Could not create the temporary vector layer.</source>
        <translation>Konnte den temporären Vektorlayer nicht erzeugen.</translation>
    </message>
    <message>
        <location filename="../modules/geopackage.py" line="223"/>
        <source>Could not start editing the new GeoPackage layer.</source>
        <translation>Konnte den neuen Layer nicht in den Bearbeitungsmodus versetzen.</translation>
    </message>
    <message>
        <location filename="../modules/geopackage.py" line="250"/>
        <source>Invalid Layer Name</source>
        <translation>Ungültiger Layername</translation>
    </message>
    <message>
        <location filename="../modules/geopackage.py" line="265"/>
        <source>The project&apos;s GeoPackage does not exist.</source>
        <translation>Das Projekt-GeoPackage existiert nicht.</translation>
    </message>
    <message>
        <location filename="../modules/geopackage.py" line="283"/>
        <source>Could not find these tables in the GeoPackage: </source>
        <translation>Konnte folgende Tabellen im GeoPackage nicht finden: </translation>
    </message>
    <message>
        <location filename="../modules/geopackage.py" line="300"/>
        <source>Could not open the GeoPackage for editing.</source>
        <translation>Konnte das GeoPackage nicht zur Bearbeitung öffnen.</translation>
    </message>
    <message>
        <location filename="../modules/geopackage.py" line="317"/>
        <source>Could not delete GeoPackage table: </source>
        <translation>Konnte folgende GeoPackage-Tabellen nicht löschen: </translation>
    </message>
    <message>
        <location filename="../modules/geopackage.py" line="380"/>
        <source>Delete Layers and Data Sources</source>
        <translation>Layer und Datenquellen löschen</translation>
    </message>
    <message>
        <location filename="../modules/geopackage.py" line="444"/>
        <source>Shared Data Source Warning</source>
        <translation>Warnung - Datenquelle mit mehreren Layern</translation>
    </message>
    <message>
        <location filename="../modules/geopackage.py" line="462"/>
        <source>Could not configure the shared-source warning dialog.</source>
        <translation>Konnte die Warnung zu Datenquelle mit meheren Layern nicht konfigurieren.</translation>
    </message>
    <message>
        <location filename="../modules/geopackage.py" line="467"/>
        <source>Delete All Affected Layers</source>
        <translation>Alle betroffenen Layer löschen</translation>
    </message>
</context>
<context>
    <name>LayerLocation</name>
    <message>
        <location filename="../modules/constants.py" line="472"/>
        <source>&lt;p&gt;🔗&lt;b&gt;Cloud Layer&lt;/b&gt;🔗&lt;/p&gt;This layer is from a cloud-based service or database.&lt;br&gt;&lt;i&gt;(Plugin: UTEC Layer Tools)&lt;/i&gt;</source>
        <translation>&lt;p&gt;🔗&lt;b&gt;Cloud Layer&lt;/b&gt;🔗&lt;/p&gt;Dieser Layer wird online oder von einer Datenbank bezogen.&lt;br&gt;&lt;i&gt;(Plugin: UTEC Layer Tools)&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../modules/constants.py" line="476"/>
        <source>&lt;p&gt;❓&lt;b&gt;Empty Layer&lt;/b&gt;❓&lt;/p&gt;This Layer does not contain any objects.&lt;br&gt;&lt;i&gt;(Plugin: UTEC Layer Tools)&lt;/i&gt;</source>
        <translation>&lt;p&gt;❓&lt;b&gt;Layer leer&lt;/b&gt;❓&lt;/p&gt;Dieser Layer enthält keine Objekte.&lt;br&gt;&lt;i&gt;(Plugin: UTEC Layer Tools)&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../modules/constants.py" line="480"/>
        <source>&lt;p&gt;💥💥💥&lt;b&gt;Caution&lt;/b&gt;💥💥💥&lt;/p&gt;This layer is stored outside the project folder. Please move to the project folder.&lt;br&gt;&lt;i&gt;(Plugin: UTEC Layer Tools)&lt;/i&gt;</source>
        <translation>&lt;p&gt;💥💥💥&lt;b&gt;Vorsicht&lt;/b&gt;💥💥💥&lt;/p&gt;Dieser Layer ist nicht im Projektordner abgespeichert. Bitte in den Projektordner verschieben.&lt;br&gt;&lt;i&gt;(Plugin: UTEC Layer Tools)&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../modules/constants.py" line="484"/>
        <source>&lt;p&gt;⚠️&lt;b&gt;Layer in Project Folder but not GeoPackage&lt;/b&gt;⚠️&lt;/p&gt;This layer is stored in the project folder, but not in a GeoPackage. Consider saving to the Project-GeoPackage (a GeoPackage with the same name as the project file).&lt;br&gt;&lt;i&gt;(Plugin: UTEC Layer Tools)&lt;/i&gt;</source>
        <translation>&lt;p&gt;⚠️&lt;b&gt;Layer im Projektordner, aber nicht in einem GeoPackage&lt;/b&gt;⚠️&lt;/p&gt;Dieser Layer ist im Projektordner, aber nicht in einem GeoPackage abgespeichert. Falls möglich und sinnvoll sollte er in das Projekt-Geopackage (ein GeoPackage mit dem gleichen Namen wie die Projektdatei) verschoben werden.&lt;br&gt;&lt;i&gt;(Plugin: UTEC Layer Tools)&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../modules/constants.py" line="488"/>
        <source>&lt;p&gt;⚠️&lt;b&gt;Layer in GeoPackge in Project Folder&lt;/b&gt;⚠️&lt;/p&gt;This layer is stored in a GeoPackage in the project folder, but not in the Project-GeoPackage. Consider saving to the Project-GeoPackage (a GeoPackage with the same name as the project file).&lt;br&gt;&lt;i&gt;(Plugin: UTEC Layer Tools)&lt;/i&gt;</source>
        <translation>&lt;p&gt;⚠️&lt;b&gt;Layer in einem GeoPackge im Projektordner&lt;/b&gt;⚠️&lt;/p&gt;Dieser Layer ist in einem GeoPackage im Projektordner, aber nicht im Projekt-GeoPackage abgespeichert. Falls möglich und sinnvoll sollte er in das Projekt-Geopackage (ein GeoPackage mit dem gleichen Namen wie die Projektdatei) verschoben werden.&lt;br&gt;&lt;i&gt;(Plugin: UTEC Layer Tools)&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../modules/constants.py" line="492"/>
        <source>&lt;p&gt;👍&lt;b&gt;Layer in Project-Geopackage&lt;/b&gt;👍&lt;/p&gt;This layer is stored in the Project-GeoPackage (a GeoPackage with the same name as the project file).&lt;br&gt;&lt;i&gt;(Plugin: UTEC Layer Tools)&lt;/i&gt;</source>
        <translation>&lt;p&gt;👍&lt;b&gt;Layer im Projekt-Geopackage&lt;/b&gt;👍&lt;/p&gt;Dieser Layer ist im Projekt-GeoPackage (ein GeoPackage mit dem gleichen Namen wie die Projektdatei) abgespeichert.&lt;br&gt;&lt;i&gt;(Plugin: UTEC Layer Tools)&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../modules/constants.py" line="496"/>
        <source>&lt;p&gt;❓&lt;b&gt;Data Source Unknown&lt;/b&gt;❓&lt;/p&gt;The data source of this Layer could not be determined.&lt;br&gt;&lt;i&gt;(Plugin: UTEC Layer Tools)&lt;/i&gt;</source>
        <translation>&lt;p&gt;❓&lt;b&gt;Datenquelle Unbekannt&lt;/b&gt;❓&lt;/p&gt;Die Quelle der Daten dieses Layers konnten nicht ermittelt werden.&lt;br&gt;&lt;i&gt;(Plugin: UTEC Layer Tools)&lt;/i&gt;</translation>
    </message>
</context>
<context>
    <name>Menu_Button</name>
    <message>
        <location filename="../UTEC_layer_tools.py" line="267"/>
        <source>Copy Selected Layers to Project&apos;s GeoPackage</source>
        <translation>Gewählte Layer ins Projekt-GeoPackage kopieren</translation>
    </message>
    <message>
        <location filename="../UTEC_layer_tools.py" line="323"/>
        <source>Rename Selected Layers by Group Name</source>
        <translation>Gewählte Layer nach Gruppenname umbenennen</translation>
    </message>
    <message>
        <location filename="../UTEC_layer_tools.py" line="341"/>
        <source>Rename and Copy Selected Layers to Project&apos;s GeoPackage</source>
        <translation>Gewählte Layer Umbenennen und ins Projekt-GeoPackage kopieren</translation>
    </message>
    <message>
        <location filename="../UTEC_layer_tools.py" line="359"/>
        <source>Undo Last Rename</source>
        <translation>Letzte Umbenennung Rückgängig machen</translation>
    </message>
    <message>
        <location filename="../UTEC_layer_tools.py" line="285"/>
        <source>Prepare Selected Layers for Sending</source>
        <translation>Gewählte Layer für den Versand vorbereiten</translation>
    </message>
    <message>
        <location filename="../UTEC_layer_tools.py" line="212"/>
        <source>Create Layout</source>
        <translation>Layout erstellen</translation>
    </message>
    <message>
        <location filename="../UTEC_layer_tools.py" line="193"/>
        <source>Edit Project Variables</source>
        <translation>Projektvariablen Bearbeiten</translation>
    </message>
    <message>
        <location filename="../UTEC_layer_tools.py" line="229"/>
        <source>Export Layouts as PDF</source>
        <translation>Layouts als PDF exportieren</translation>
    </message>
    <message>
        <location filename="../UTEC_layer_tools.py" line="249"/>
        <source>Create New Layer in Project&apos;s GeoPackage</source>
        <translation>Neuen GeoPackage-Layer erzeugen</translation>
    </message>
    <message>
        <location filename="../UTEC_layer_tools.py" line="303"/>
        <source>Delete Selected Layers from the Project and from the Project&apos;s GeoPackage</source>
        <translation>Gewählte Layer und deren Quellen aus dem Projekt und dem Projekt-GeoPackage löschen</translation>
    </message>
</context>
<context>
    <name>Menu_ToolTip</name>
    <message>
        <location filename="../UTEC_layer_tools.py" line="268"/>
        <source>&lt;p&gt;&lt;b&gt;Copy Selected Layers to Project&apos;s GeoPackage&lt;/b&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&apos;font-weight:normal; font-style:normal;&apos;&gt;Selected layers and layers in selected groups are copied to the project&apos;s GeoPackage and added back from the GeoPackage to the top of the layer tree of the current project. The original layers can be removed from the project if desired.&lt;/p&gt;&lt;p&gt;The project&apos;s GeoPackage is a GeoPackage (.gpkg) in the project folder with the same name as the project file (.qgz).&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;b&gt;CAUTION: This will overwrite layers with the same name and geometry type in the project&apos;s GeoPackage!&lt;/b&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Gewählte Layer in das Projekt-GeoPackage Kopieren&lt;/b&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&apos;font-weight:normal; font-style:normal;&apos;&gt;Gewählte Layer und Layer in gewählten Gruppen werden in das Projekt-GeoPackage kopiert und von dort in das Projekt (im Layer-Baum ganz oben) eingefügt. Die Ausgangslayer können danach, wenn gewünscht, aus dem Projekt gelöscht werden.&lt;/p&gt;&lt;p&gt;Das Projekt-GeoPackage ist ein GeoPackage (.gpkg) im Projektordner mit dem gleichen Namen wie die Projektdatei (.qgz).&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Vorsicht: Layer mit mit gleichem Namen und gleichem Geometrietyp im Projekt-GeoPackage werden überschrieben!&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../UTEC_layer_tools.py" line="324"/>
        <source>&lt;p&gt;&lt;b&gt;Rename Selected Layers by Group Name&lt;/b&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&apos;font-weight:normal; font-style:normal;&apos;&gt;Selected layers and layers in selected groups are renamed according to their parent group names. If a layer is not in a group, it is not renamed.&lt;/p&gt;&lt;p&gt;(Mostly useful for renaming layers imported from AutoCAD)&lt;/span&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Gewählte Layer nach Gruppenname Umbenennen&lt;/b&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&apos;font-weight:normal; font-style:normal;&apos;&gt;Gewählte Layer und Layer in gewählten Gruppen werden umbenannt, so dass ihr Name der Gruppe entspricht, in der sie liegen. Layer, die sich nicht in einer Gruppe befinden, wird er nicht umbenannt.&lt;/p&gt;&lt;p&gt;(Nützlich für das Umbenennen von Layern, die aus AutoCAD importiert wurden)&lt;/span&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../UTEC_layer_tools.py" line="342"/>
        <source>&lt;p&gt;&lt;b&gt;Rename and Copy Selected Layers to Project&apos;s GeoPackage&lt;/b&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&apos;font-weight:normal; font-style:normal;&apos;&gt;Selected layers and layers in selected groups are renamed according to their parent group names, then copied to the project&apos;s GeoPackage and then added back from the GeoPackage to the top of the layer tree of the current project. The original layers can be removed from the project if desired.&lt;/p&gt;&lt;p&gt;The project&apos;s GeoPackage is a GeoPackage (.gpkg) in the project folder with the same name as the project file (.qgz).&lt;/span&gt;&lt;/p&gt;&lt;b&gt;CAUTION: This will overwrite layers with the same name and geometry type in the project&apos;s GeoPackage!&lt;/b&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Gewählte Layer Umbenennen und in das Projekt-GeoPackage Kopieren&lt;/b&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&apos;font-weight:normal; font-style:normal;&apos;&gt;Gewählte Layer und Layer in gewählten Gruppen werden umbenannt, so dass ihr Name der Gruppe entspricht, in der sie liegen, danach in das Projekt-GeoPackage kopiert und von dort in das Projekt (im Layer-Baum ganz oben) eingefügt. Die Ausgangslayer können danach, wenn gewünscht, aus dem Projekt gelöscht werden.&lt;/p&gt;&lt;p&gt;Das Projekt-GeoPackage ist ein GeoPackage (.gpkg) im Projektordner mit dem gleichen Namen wie die Projektdatei (.qgz).&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Vorsicht: Layer mit mit gleichem Namen und gleichem Geometrietyp im Projekt-GeoPackage werden überschrieben!&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../UTEC_layer_tools.py" line="360"/>
        <source>&lt;p&gt;&lt;b&gt;Undo Last Rename&lt;/b&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&apos;font-weight:normal; font-style:normal;&apos;&gt;Undoes the most recent layer renaming operation performed by this plugin.&lt;/span&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Letzte Umbenennung Rückgängig Machen&lt;/b&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&apos;font-weight:normal; font-style:normal;&apos;&gt;Die letzte Umbenennung, die von diesem Plugin ausgeführt wurde, wird rückgängig gemacht.&lt;/span&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../UTEC_layer_tools.py" line="286"/>
        <source>&lt;p&gt;&lt;b&gt;Prepare Selected Layers for Sending&lt;/b&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&apos;font-weight:normal; font-style:normal;&apos;&gt;Creates a subfolder in the project folder with a GeoPackage (.gpkg) and a project file (.qgz) containing the selected layers. These two files can be sent e.g. via email.&lt;/span&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Gewälte Layer für Versand Vorbereiten&lt;/b&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&apos;font-weight:normal; font-style:normal;&apos;&gt;Im Projektordner wird ein Unterordner mit einem GeoPackage (.gpkg) und einer Projektdatei (.qgz) erstellt, die die gewählten Layer enthalten. Diese beiden Dateien können z.B. per E-Mail versendet werden.&lt;/span&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../UTEC_layer_tools.py" line="194"/>
        <source>&lt;p&gt;&lt;b&gt;Edit Project Variables&lt;/b&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&apos;font-weight:normal; font-style:normal;&apos;&gt;Define project-specific metadata like project number and name. These are stored as project variables (see Project → Properties...) and can be used in expressions, e.g. [% @project_number %].&lt;/span&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Projektvariablen bearbeiten&lt;/b&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&apos;font-weight:normal; font-style:normal;&apos;&gt;Metadaten wie Projektnummer und Name definieren. Diese werden als Projektvariablen gespeichert (siehe Projekt → Eigenschaften...) und können in Ausdrücken verwendet werden, z.B. [% @project_number %].&lt;/span&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../UTEC_layer_tools.py" line="230"/>
        <source>&lt;p&gt;&lt;b&gt;Export Layouts as PDF&lt;/b&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&apos;font-weight:normal; font-style:normal;&apos;&gt;Select layouts to be exported as PDF files. The PDFs will be saved in the specified folder (defaults to &apos;pdf&apos; within the project directory) without overwriting existing files. Existing files with the same name will be moved to a folder called &apos;alt&apos;.&lt;/span&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Layouts als PDF exportieren&lt;/b&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&apos;font-weight:normal; font-style:normal;&apos;&gt;Layouts wählen, die als PDF-Dateien exportiert werden sollen. Die Dateien werden im angegebenen Ordner (Standardordner: &apos;pdf&apos; im Projektverzeichnis) gespeichert ohne vorhandene Dateien zu überschreiben. Vorhandene Dateien mit demselben Namen werden in einen Unterordner namens &apos;alt&apos; verschoben.&lt;/span&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../UTEC_layer_tools.py" line="250"/>
        <source>&lt;p&gt;&lt;b&gt;Create New Layer in Project&apos;s GeoPackage&lt;/b&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&apos;font-weight:normal; font-style:normal;&apos;&gt;Creates a new layer in the project&apos;s GeoPackage. The new layer is added to the top of the layer tree of the current project.&lt;/span&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Neuen Layer im Projekt-GeoPackage Erstellen&lt;/b&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&apos;font-weight:normal; font-style:normal;&apos;&gt;Erstellt einen neuen Layer im Projekt-GeoPackage. Der neue Layer wird von dort in das Projekt (im Layer-Baum ganz oben) eingefügt.&lt;/span&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../UTEC_layer_tools.py" line="304"/>
        <source>&lt;p&gt;&lt;b&gt;Delete Selected Layers from the Project and from the Project&apos;s GeoPackage&lt;/b&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&apos;font-weight:normal; font-style:normal;&apos;&gt;!!! CAUTION !!! Selected layers and layers in selected groups are deleted from the project as well as from the project&apos;s GeoPackage.&lt;/span&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Gewählte Layer aus dem Projekt-GeoPackage Löschen&lt;/b&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&apos;font-weight:normal; font-style:normal;&apos;&gt;!!! VORSICHT !!!Gewählte Layer und Layer in gewählten Gruppen werden sowohl aus dem Projekt, als auch aus dem Projekt-GeoPackage gelöscht.&lt;/span&gt;&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>PaperSizes</name>
    <message>
        <location filename="../modules/constants.py" line="111"/>
        <source>A4 Landscape</source>
        <translation>A4 Querformat</translation>
    </message>
    <message>
        <location filename="../modules/constants.py" line="123"/>
        <source>A4 Portrait</source>
        <translation>A4 Hochformat</translation>
    </message>
    <message>
        <location filename="../modules/constants.py" line="135"/>
        <source>A3 Landscape</source>
        <translation>A3 Querformat</translation>
    </message>
    <message>
        <location filename="../modules/constants.py" line="147"/>
        <source>A3 Portrait</source>
        <translation>A3 Hochformat</translation>
    </message>
    <message>
        <location filename="../modules/constants.py" line="159"/>
        <source>A2 Landscape</source>
        <translation>A2 Querformat</translation>
    </message>
    <message>
        <location filename="../modules/constants.py" line="170"/>
        <source>A2 Portrait</source>
        <translation>A2 Hochformat</translation>
    </message>
    <message>
        <location filename="../modules/constants.py" line="181"/>
        <source>A1 Landscape</source>
        <translation>A1 Querformat</translation>
    </message>
    <message>
        <location filename="../modules/constants.py" line="192"/>
        <source>A1 Portrait</source>
        <translation>A1 Hochformat</translation>
    </message>
    <message>
        <location filename="../modules/constants.py" line="203"/>
        <source>A0 Landscape</source>
        <translation>A0 Querformat</translation>
    </message>
    <message>
        <location filename="../modules/constants.py" line="214"/>
        <source>A0 Portrait</source>
        <translation>A0 Hochformat</translation>
    </message>
</context>
<context>
    <name>PrintLayout</name>
    <message>
        <location filename="../modules/print_layout.py" line="105"/>
        <source>Create Print Layout</source>
        <translation>Neues Drucklayout Erzeugen</translation>
    </message>
    <message>
        <location filename="../modules/print_layout.py" line="165"/>
        <source>Paper Format</source>
        <translation>Papierformat</translation>
    </message>
    <message>
        <location filename="../modules/print_layout.py" line="146"/>
        <source>Landscape</source>
        <translation>Querformat</translation>
    </message>
    <message>
        <location filename="../modules/print_layout.py" line="147"/>
        <source>Portrait</source>
        <translation>Hochformat</translation>
    </message>
    <message>
        <location filename="../modules/print_layout.py" line="85"/>
        <source>Overview</source>
        <translation>Übersichtsplan</translation>
    </message>
    <message>
        <location filename="../modules/print_layout.py" line="523"/>
        <source>Frame</source>
        <translation>Rahmen</translation>
    </message>
    <message>
        <location filename="../modules/print_layout.py" line="229"/>
        <source>Source</source>
        <translation>Quelle</translation>
    </message>
    <message>
        <location filename="../modules/print_layout_export.py" line="49"/>
        <source>Export Layouts as PDF</source>
        <translation>Layouts als PDF exportieren</translation>
    </message>
    <message>
        <location filename="../modules/print_layout_export.py" line="102"/>
        <source>Export Settings</source>
        <translation>Export Einstellungen</translation>
    </message>
    <message>
        <location filename="../modules/print_layout_export.py" line="163"/>
        <source>Export Folder:</source>
        <translation>Zielordner:</translation>
    </message>
    <message>
        <location filename="../modules/print_layout_export.py" line="261"/>
        <source>Select Export Directory</source>
        <translation>Zielordner wählen</translation>
    </message>
    <message>
        <location filename="../modules/print_layout_export.py" line="173"/>
        <source>Resolution</source>
        <translation>Auflösung</translation>
    </message>
    <message>
        <location filename="../modules/print_layout_export.py" line="174"/>
        <source>Append georeference information</source>
        <translation>Georeferenzinformation anhängen</translation>
    </message>
    <message>
        <location filename="../modules/print_layout_export.py" line="175"/>
        <source>Include georeferencing information in the PDF header. Allows compatible viewers to display coordinates.</source>
        <translation>Georeferenzinformationen in das PDF-Dokument schreiben. Dies erlaubt kompatibler Software Koordinaten anzuzeigen.</translation>
    </message>
    <message>
        <location filename="../modules/print_layout_export.py" line="176"/>
        <source>Export metadata</source>
        <translation>Metadaten exportieren</translation>
    </message>
    <message>
        <location filename="../modules/print_layout_export.py" line="177"/>
        <source>Include document metadata (author, title, etc.) in the PDF.</source>
        <translation>Informationen wie z. B. Titel, Autor, Datum, etc. werden mit exportiert.</translation>
    </message>
    <message>
        <location filename="../modules/print_layout_export.py" line="178"/>
        <source>Simplify geometry</source>
        <translation>Geometrien vereinfachen</translation>
    </message>
    <message>
        <location filename="../modules/print_layout_export.py" line="179"/>
        <source>Simplify geometry to reduce file size.</source>
        <translation>Dies kann die Größe und Komplexität der Exportdatei reduzieren.</translation>
    </message>
    <message>
        <location filename="../modules/print_layout.py" line="125"/>
        <source>Drawing Type</source>
        <translation>Planart</translation>
    </message>
    <message>
        <location filename="../tests/qgis/test_print_layout.py" line="98"/>
        <source>Drafter</source>
        <translation>gezeichnet</translation>
    </message>
    <message>
        <location filename="../tests/qgis/test_print_layout.py" line="100"/>
        <source>Checker</source>
        <translation>geprüft</translation>
    </message>
    <message>
        <location filename="../modules/print_layout.py" line="216"/>
        <source>Source of Background Maps: LGLN Niedersachsen</source>
        <translation>Quelle Hintergrundkarte: LGLN Niedersachsen</translation>
    </message>
    <message>
        <location filename="../modules/print_layout_export.py" line="143"/>
        <source>File Name Prefix:</source>
        <translation>Dateinamenprefix:</translation>
    </message>
    <message>
        <location filename="../modules/print_layout.py" line="208"/>
        <source>Legend</source>
        <translation>Legende</translation>
    </message>
</context>
<context>
    <name>ProjectVariables</name>
    <message>
        <location filename="../modules/project_variables.py" line="120"/>
        <source>Edit Project Variables</source>
        <translation>Projektvariablen Bearbeiten</translation>
    </message>
    <message>
        <location filename="../modules/project_variables.py" line="76"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="../modules/project_variables.py" line="68"/>
        <source>Developer</source>
        <translation>Bauherr</translation>
    </message>
    <message>
        <location filename="../modules/project_variables.py" line="62"/>
        <source>Project Number</source>
        <translation>Projektnummer</translation>
    </message>
    <message>
        <location filename="../modules/project_variables.py" line="68"/>
        <source>Project Developer</source>
        <translation>Bauherr</translation>
    </message>
    <message>
        <location filename="../modules/project_variables.py" line="76"/>
        <source>Project Name</source>
        <translation>Projekt</translation>
    </message>
</context>
<context>
    <name>RenameDialog</name>
    <message>
        <location filename="../modules/rename.py" line="71"/>
        <source>Remove Words from New Names</source>
        <translation>Aus Neuen Namen Löschen</translation>
    </message>
    <message>
        <location filename="../modules/rename.py" line="79"/>
        <source>Default words to remove</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="../modules/rename.py" line="102"/>
        <source>e.g., test, draft, temp</source>
        <translation>z.B. test, Entwurf, temp</translation>
    </message>
    <message>
        <location filename="../modules/rename.py" line="105"/>
        <source>Additional words (comma-separated):</source>
        <translation>Zusätzlich (mit Komma getrennt):</translation>
    </message>
</context>
<context>
    <name>RuntimeError</name>
    <message>
        <location filename="../UTEC_layer_tools.py" line="181"/>
        <source>Failed to create the plugin menu.</source>
        <translation>Konnte das Plugin-Menu nicht erstellen.</translation>
    </message>
    <message>
        <location filename="../modules/general.py" line="42"/>
        <source>QGIS interface not set.</source>
        <translation>Das OGIS Interface ist nicht gesetzt.</translation>
    </message>
    <message>
        <location filename="../modules/general.py" line="43"/>
        <source>Could not get layer tree view.</source>
        <translation>Konnte den Layer-Baum nicht öffnen.</translation>
    </message>
    <message>
        <location filename="../modules/general.py" line="44"/>
        <source>No layers or groups selected.</source>
        <translation>Keine Layer oder Layer-Gruppen ausgewählt.</translation>
    </message>
    <message>
        <location filename="../modules/geopackage.py" line="1134"/>
        <source>Could not get layer tree root.</source>
        <translation>Konnte &quot;layer tree root&quot; nicht finden.</translation>
    </message>
</context>
<context>
    <name>Shipping</name>
    <message>
        <location filename="../modules/shipping.py" line="127"/>
        <source>Shipping</source>
        <translation>Versand</translation>
    </message>
</context>
<context>
    <name>UserError</name>
    <message>
        <location filename="../modules/context.py" line="181"/>
        <source>Project is not saved. Please save the project first.</source>
        <translation>Das Projekt ist noch nicht abgespeichert. Bitte erst speichern.</translation>
    </message>
</context>
<context>
    <name>location_multi</name>
    <message>
        <location filename="../modules/layer_location.py" line="177"/>
        <source>Shared Data Source</source>
        <translation>Datenquelle wird von mehreren Layern verwendet</translation>
    </message>
    <message>
        <location filename="../modules/layer_location.py" line="178"/>
        <source>Folder</source>
        <translation>Ordner</translation>
    </message>
    <message>
        <location filename="../modules/layer_location.py" line="179"/>
        <source>File</source>
        <translation>Datei</translation>
    </message>
    <message>
        <location filename="../modules/layer_location.py" line="180"/>
        <source>Layer</source>
        <translation>Layer</translation>
    </message>
    <message>
        <location filename="../modules/layer_location.py" line="181"/>
        <source>Used by:</source>
        <translation>Benutzt von:</translation>
    </message>
</context>
<context>
    <name>log_summary</name>
    <message>
        <location filename="../modules/logs_and_errors.py" line="129"/>
        <source>{amount} layers processed. (skipped actions: {skipped} / errors: {errors})</source>
        <translation>{amount} Layer verarbeitet. (Übersprungene Vorgänge: {skipped} / Fehler: {errors})</translation>
    </message>
    <message>
        <location filename="../modules/logs_and_errors.py" line="130"/>
        <source> → For more inforation on skipped actions and errors, see the plugin log.</source>
        <translation> → nähere Informationen zu übersprungenen Vorgängen und Fehlern im Protokoll.</translation>
    </message>
</context>
</TS>
